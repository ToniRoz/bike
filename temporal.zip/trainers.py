"""
Todo:
    read and remove useless ai comments (done)
    add dynamic state space from env (rainbow)(done)
    add lstm support (rainbow) (ppo) should take the action with the last states
    add logging for tensions and turns (done)
"""
import os
import bz2
import pickle
from datetime import datetime
from pathlib import Path
from collections import deque, defaultdict
import numpy as np
import torch
from tqdm import trange, tqdm
import jax

from config import RainbowConfig, PPOConfig
from Agents import RainbowAgent, PPOAgent
from Memory import ReplayMemory

import gymnasium as gym

from omegaconf import OmegaConf

from pathlib import Path
import hydra

from pathlib import Path
from hydra.core.hydra_config import HydraConfig  # ✅ this import is required
import os

class BaseTrainer:
    def __init__(self, config, env, writer=None, output_dir=None):
        self.config = config
        self.env = env
        self.writer = writer

        # --- Hydra-safe output directory setup ---
        if output_dir is not None:
            # Use the provided output_dir (from experiment script)
            self.run_dir = Path(output_dir)
        else:
            try:
                # Works when running under a Hydra-managed script (e.g. train_rainbow.py with @hydra.main)
                self.run_dir = Path(HydraConfig.get().runtime.output_dir)
            except Exception:
                # Fallback for non-Hydra contexts (e.g. debugging manually)
                self.run_dir = Path("/tmp/rainbow_fallback")
                print(f"[BaseTrainer] Warning: HydraConfig not initialized, using {self.run_dir}")

        # --- Make sure directories exist ---
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_dir = self.run_dir / "checkpoints"
        self.tensorboard_dir = self.run_dir / "tensorboard"
        self.results_dir = self.run_dir / "results"

        for d in [self.checkpoint_dir, self.tensorboard_dir, self.results_dir]:
            d.mkdir(exist_ok=True)

        # Optional: print for debugging
        print(f"[BaseTrainer] Run directory: {self.run_dir}")
        print(f"[BaseTrainer] Checkpoints -> {self.checkpoint_dir}")
        print(f"[BaseTrainer] TensorBoard  -> {self.tensorboard_dir}")
        print(f"[BaseTrainer] Results      -> {self.results_dir}")

    def log(self, message):
        from datetime import datetime
        timestamp = datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
        print(f"[{timestamp}] {message}")
    
    def save_checkpoint(self, path, epoch):
        raise NotImplementedError
    
    def train(self):
        raise NotImplementedError
    
    def evaluate(self):
        raise NotImplementedError


class RainbowTrainer(BaseTrainer):
    """Trainer for Rainbow DQN"""
    
    def __init__(self, config, env, writer=None, output_dir=None):
        # Pass output_dir to parent class
        super().__init__(config, env, writer, output_dir=output_dir)
        
        self.env = env
        
        # Infer state shape from environment
        if isinstance(env.observation_space, gym.spaces.Box):
            state_shape = env.observation_space.shape
        else:
            raise ValueError(f"Unsupported observation space: {type(env.observation_space)}")
        
        self.log(f"[RainbowTrainer] State shape: {state_shape}")
        
        self.agent = RainbowAgent(config, self.env)
        
        # Setup memory 
        from Memory import ReplayMemory
        if config.model_path and config.memory_path and os.path.exists(config.memory_path):
            self.memory = self._load_memory(config.memory_path)
            self.log("Loaded memory from checkpoint")
        else:
            self.memory = ReplayMemory(config, config.memory_capacity, state_shape)
        
        # Validation memory 
        self.val_memory = self._create_validation_memory(state_shape)

        
        # Training metrics
        self.metrics = {
            'steps': [],
            'rewards': [],
            'Qs': [],
            'best_avg_reward': -float('inf')
        }
        
        # Priority weight annealing
        self.priority_weight_increase = (
            (1 - config.priority_weight) / (config.T_max - config.learn_start)
        )

    
    def _create_validation_memory(self, state_shape):  
        """Create validation memory"""
        val_mem = ReplayMemory(self.config, self.config.evaluation_size, state_shape)
        T, done = 0, True
        
        while T < self.config.evaluation_size:
            if done:
                state, _ = self.env.reset()
            
            action = self.env.action_space.sample()
            next_state, reward, terminated, truncated, _ = self.env.step(action)
            
            val_mem.append(state, -1, 0.0, done)
            state = next_state
            done = terminated or truncated
            T += 1
        
        return val_mem
    
    def _load_memory(self, path):
        """Load memory from file"""
        with bz2.open(path, 'rb') as f:
            return pickle.load(f)
    
    def _save_memory(self, path):
        """Save memory to file"""
        with bz2.open(path, 'wb') as f:
            pickle.dump(self.memory, f)
    
    def train(self):
        """Main training loop with debug logging"""
        self.log(f"Starting Rainbow training for {self.config.T_max} steps")
        
        self.agent.train()
        done = False
        episode_reward = 0
        episode_counter = 0
        step_counter = 0
        glob_step = 0
        first_state_norm = -1000
        first_tensions = 1000
        first_turns = 1

        try:
            state, _ = self.env.reset()
            self.agent.reset_episode()
        except Exception as e:
            self.log(f"Error during env.reset(): {e}")
            return

        for T in trange(1, self.config.T_max + 1):
            try:
                # Episode management
                if done:
                    try:
                        if self.writer and state is not None:
                            # Only compute wheel_change if info exists
                            if 'raw state norm' in info:
                                current_norm = info['raw state norm']
                                current_tension = np.sum(abs(info['tensions delta']))
                                current_turns = np.sum(abs(info['spoke turns']))

                                current_tensions_max = np.max(abs(info['tensions delta']))
                                current_turns_max = np.max(abs(info['spoke turns']))
                                max_displacement = info["max disp"]
                                terminated = info["terminated"]

                                wheel_change = 100 * (first_state_norm - current_norm) / max(abs(first_state_norm), 1e-15)
                                turn_change = 100 * (first_turns - current_turns) / max(abs(first_turns), 1e-15)
                                tension_change = 100 * (first_tensions - current_tension) / max(abs(first_tensions), 1e-15)
                                self.writer.add_scalar(f'episode/return', episode_reward, glob_step)
                                self.writer.add_scalar(f'episode/length', step_counter, glob_step)
                                self.writer.add_scalar(f'environment/wheel improvement', wheel_change, glob_step)
                                self.writer.add_scalar(f'environment/tension improvement', tension_change, glob_step)
                                self.writer.add_scalar(f'environment/turn improvement', turn_change, glob_step)
                                self.writer.add_scalar(f'environment/final state norm', current_norm, glob_step)

                                self.writer.add_scalar(f'environment/final tension deltas max', current_tensions_max, glob_step)
                                self.writer.add_scalar(f'environment/final tension deltas sum', current_tension, glob_step)
                                self.writer.add_scalar(f'environment/final turns max', current_turns_max, glob_step)
                                self.writer.add_scalar(f'environment/final turns sum', current_turns, glob_step)
                                self.writer.add_scalar(f'environment/wheel max', max_displacement, glob_step)
                                if terminated:
                                    self.writer.add_scalar(f'episode/terminated', 1, glob_step)
                                else:
                                    self.writer.add_scalar(f'episode/terminated', 0, glob_step)

                            else:
                                self.log(f"Warning: 'raw state norm' missing in info at episode {episode_counter}")
                    except Exception as e:
                        self.log(f"Error during episode logging: {e}")

                    episode_counter += 1
                    episode_reward = 0
                    step_counter = 0
                    state, info = self.env.reset()
                    self.agent.reset_episode()
                    first_state_norm = info['raw state norm']
                    self.writer.add_scalar(f'environment/initial state norm', first_state_norm, glob_step)
                    self.writer.add_scalar(f'environment/initial tension deltas sum', np.sum(np.abs(info['tensions delta'])),glob_step) 
                    self.writer.add_scalar(f'environment/initial tension deltas max', np.max(np.abs(info['tensions delta'])),glob_step)
                    self.writer.add_scalar(f'environment/initial turns sum', np.sum(np.abs(info['spoke turns'])), glob_step)
                    self.writer.add_scalar(f'environment/initial turns max', np.max(np.abs(info['spoke turns'])), glob_step)
                    first_tensions = np.sum(np.abs(info['tensions delta']))
                    first_turns = np.sum(abs(info['spoke turns']))
                    done = False 

                # Reset noise
                if T % self.config.replay_frequency == 0:
                    self.agent.reset_noise()

                # Take action
                action = self.agent.act(state)
                next_state, reward, terminated, truncated, info = self.env.step(action)

                if terminated or truncated:
                    done = True
                step_counter += 1
                glob_step += 1

                # Clip rewards if needed
                if self.config.reward_clip > 0:
                    reward = max(min(reward, self.config.reward_clip), -self.config.reward_clip)

                episode_reward += reward
                self.memory.append(state, action, reward, done)

                # Training
                if T >= self.config.learn_start:
                    # Anneal importance sampling weight
                    self.memory.priority_weight = min(
                        self.memory.priority_weight + self.priority_weight_increase, 1
                    )

                    # Learn
                    if T % self.config.replay_frequency == 0:
                        try:
                            self.agent.learn(self.memory)
                            # Optional: check for NaNs in network
                            if hasattr(self.agent, 'q_values') and torch.isnan(self.agent.q_values).any():
                                self.log(f"NaNs detected in Q-values at step {T}")
                                break
                        except Exception as e:
                            self.log(f"Error during agent.learn(): {e}")
                            break

                    # Evaluate
                    if self.config.evaluation_interval and T % self.config.evaluation_interval == 0:
                        try:
                            self._evaluate_agent(T)
                        except Exception as e:
                            self.log(f"Error during evaluation at step {T}: {e}")

                    # Update target network
                    if T % self.config.target_update == 0:
                        try:
                            self.agent.update_target_net()
                        except Exception as e:
                            self.log(f"Error during target net update at step {T}: {e}")

                    # Checkpoint
                    if self.config.checkpoint_interval and T % self.config.checkpoint_interval == 0:
                        try:
                            self.save_checkpoint(self.checkpoint_dir, T)
                        except Exception as e:
                            self.log(f"Error saving checkpoint at step {T}: {e}")

                state = next_state

            except Exception as e:
                self.log(f"Unexpected error at step {T}: {e}")
                self.log(f"Action: {action}")
                self.log(f"Reward: {reward}")
                break

        self.log("Training completed!")

    
    def _evaluate_agent(self, step):
        """Evaluate agent"""
        self.agent.eval()
        
        # Run evaluation episodes
        total_reward = 0
        total_q = 0
        
        for _ in range(self.config.evaluation_episodes):
            state, info = self.env.reset()
            self.agent.reset_episode()
            done = False
            episode_reward = 0
            
            while not done:
                action = self.agent.act_e_greedy(state)
                state, reward, terminated, truncated, info = self.env.step(action)
                episode_reward += reward
                total_q += self.agent.evaluate_q(state)
                if terminated or truncated: 
                    done = True
            
            total_reward += episode_reward
        
        avg_reward = total_reward / self.config.evaluation_episodes
        avg_q = total_q / self.config.evaluation_episodes
        
        # Log metrics
        self.log(f'Step {step}/{self.config.T_max} | Avg Reward: {avg_reward:.2f} | Avg Q: {avg_q:.2f}')
        
        if self.writer:
            self.writer.add_scalar('Eval/avg_reward', avg_reward, step)
            self.writer.add_scalar('Eval/avg_q', avg_q, step)
        
        # Save best model
        if avg_reward > self.metrics['best_avg_reward']:
            self.metrics['best_avg_reward'] = avg_reward
            self.agent.save(str(self.results_dir), 'best_model.pth')
            self.log(f"New best model saved! Reward: {avg_reward:.2f}")
        
        self.agent.train()
        
        # Save memory if path provided
        if self.config.memory_path:
            self._save_memory(self.config.memory_path)
    
    def save_checkpoint(self, path, step):
        self.agent.save(path)
        self.log(f"Checkpoint saved locally at {path}")

    
    def evaluate(self):
        """Run evaluation only"""
        self.log("Running evaluation...")
        self.agent.eval()
        self._evaluate_agent(0)



class PPOTrainer(BaseTrainer):
    """Trainer for PPO with recurrent network support"""
    
    def __init__(self, config: PPOConfig, env, writer=None, output_dir=None):
        super().__init__(config, env, writer, output_dir=output_dir)
        
        
        # Get environment dimensions
        obs_dim = env.observation_space.shape[0]
        action_dim = (env.action_space.shape[0] if config.continuous_action_space 
                     else env.action_space.n)
        
        # Create agent with recurrent support
        self.agent = PPOAgent(
            obs_dim=obs_dim,
            action_dim=action_dim,
            hidden_dim=config.hidden_dim,
            lr_actor=config.lr_actor,
            lr_critic=config.lr_critic,
            continuous_action_space=config.continuous_action_space,
            num_epochs=config.num_epochs,
            eps_clip=config.eps_clip,
            action_std_init=config.action_std_init,
            gamma=config.gamma,
            entropy_coef=config.entropy_coef,
            value_loss_coef=config.value_loss_coef,
            batch_size=config.batch_size,
            max_grad_norm=config.max_grad_norm,
            device=config.device,
            # NEW: Pass recurrent parameters from config
            use_recurrent=getattr(config, 'use_recurrent', False),
            recurrent_type=getattr(config, 'recurrent_type', 'lstm'),
            recurrent_hidden_dim=getattr(config, 'recurrent_hidden_dim', 128),
            recurrent_layers=getattr(config, 'recurrent_layers', 1),
            recurrent_sequence_length=getattr(config, 'recurrent_sequence_length', 16),
            recurrent_dropout=getattr(config, 'recurrent_dropout', 0.0),
        )
    
    def train(self):
        """Main training loop with recurrent support"""
        self.log(f"Starting PPO training for {self.config.num_train_steps} steps")
        
        t_so_far = 0
        eps_so_far = 0
        running_eps_reward = 0
        running_eps_length = 0
        
        while t_so_far < self.config.num_train_steps:
            # Reset environment
            obs, info = self.env.reset(seed=self.config.random_seed)
            
            # NEW: Reset episode state (important for recurrent networks!)
            self.agent.reset_episode()
            
            first_state_norm = info['raw state norm']
            first_tensions = np.sum(abs(info['tensions delta']))
            first_turns = np.sum(abs(info['spoke turns']))
            self.writer.add_scalar(f'environment/initial state norm', first_state_norm, t_so_far)
            self.writer.add_scalar(f'environment/initial tension deltas sum', np.sum(np.abs(info['tensions delta'])),t_so_far) 
            self.writer.add_scalar(f'environment/initial tension deltas max', np.max(np.abs(info['tensions delta'])),t_so_far)
            self.writer.add_scalar(f'environment/initial turns sum', np.sum(np.abs(info['spoke turns'])), t_so_far)
            self.writer.add_scalar(f'environment/initial turns max', np.max(np.abs(info['spoke turns'])), t_so_far)
            

            eps_reward = 0
            eps_length = 0
            step_counter = 0
            
            # Collect trajectory
            for step in range(1, self.config.max_eps_steps + 1):
                # Select action (automatically handles recurrent vs standard)
                action, logprob, value = self.agent.select_action(obs)
                
                # Take step
                next_obs, reward, done, truncated, info = self.env.step(action)
                
                if done or truncated:
                    done = True
                
                eps_reward += reward
                step_counter += 1
                t_so_far += 1
                eps_length += 1
                
                # Store transition
                self.agent.buffer.add(obs, action, logprob, reward, done, value)
                
                # Update policy
                if t_so_far % self.config.update_interval == 0:
                    self.agent.update_policy()
                
                # Save checkpoint
                if t_so_far % self.config.save_interval == 0:
                    self.save_checkpoint(self.checkpoint_dir, t_so_far)
                
                obs = next_obs
                
                if done:
                    current_norm = info['raw state norm']
                    current_tensions_max = np.max(abs(info['tensions delta']))
                    current_turns_max = np.max(abs(info['spoke turns']))
                    current_tension = np.sum(abs(info['tensions delta']))
                    current_turns = np.sum(abs(info['spoke turns']))
                    max_displacement = info["max disp"]
                    wheel_change = 100 * (first_state_norm - current_norm) / max(abs(first_state_norm), 1e-15)
                    turn_change = 100 * (first_turns - current_turns) / max(abs(first_turns), 1e-15)
                    tension_change = 100 * (first_tensions - current_tension) / max(abs(first_tensions), 1e-15)
                    terminated = info["terminated"]

                    if self.writer:
                        self.writer.add_scalar(f'episode/return', eps_reward, t_so_far)
                        self.writer.add_scalar(f'episode/length', step_counter, t_so_far)
                        self.writer.add_scalar(f'environment/wheel improvement', wheel_change, t_so_far)
                        self.writer.add_scalar(f'environment/turn improvement', turn_change, t_so_far)
                        self.writer.add_scalar(f'environment/tension improvement', tension_change, t_so_far)
                        self.writer.add_scalar(f'environment/final state norm', current_norm, t_so_far)

                        self.writer.add_scalar(f'environment/final tension deltas max', current_tensions_max, t_so_far)
                        self.writer.add_scalar(f'environment/final tension deltas sum', current_tension, t_so_far)
                        self.writer.add_scalar(f'environment/final turns max', current_turns_max, t_so_far)
                        self.writer.add_scalar(f'environment/final turns sum', current_turns, t_so_far)
                        self.writer.add_scalar(f'environment/wheel max', max_displacement, t_so_far)
                        if terminated:
                            self.writer.add_scalar(f'episode/terminated', 1, t_so_far)
                        else:
                            self.writer.add_scalar(f'episode/terminated', 0, t_so_far)
                    
                    break
            
            running_eps_reward += eps_reward
            running_eps_length += eps_length
            eps_so_far += 1
            
            # Periodic logging
            if eps_so_far % 10 == 0:
                avg_reward = running_eps_reward / 10
                avg_length = running_eps_length / 10
                self.log(f"Episode {eps_so_far} | Steps: {t_so_far} | Avg Reward: {avg_reward:.2f} | Avg Length: {avg_length:.1f}")
                running_eps_reward = 0
                running_eps_length = 0
        
        self.log("Training completed!")
    
    def save_checkpoint(self, path, step):
        """Save checkpoint using agent's save method"""
        ckpt_path = os.path.join(path, f"{self.config.env_name}_step_{step}.pt")
        self.agent.save(ckpt_path)
        self.log(f"Checkpoint saved at step {step}")
    
    def evaluate(self):
        """Run evaluation with recurrent support"""
        self.log("Running PPO evaluation...")
        
        # Load checkpoint
        ckpt_path = os.path.join(self.config.ckpt_dir, self.config.eval_ckpt_name)
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
        
        self.agent.load(ckpt_path, load_optimizer=False)
        self.agent.policy.eval()
        
        metrics = {
            'eps_rewards': [],
            'eps_lengths': [],
            'min_reward': float('inf'),
            'max_reward': float('-inf'),
        }
        
        recent_rewards = deque(maxlen=10)
        
        with torch.no_grad():
            for ep in range(self.config.num_eval_eps):
                obs, _ = self.env.reset()
                
                # NEW: Reset episode state for recurrent networks
                self.agent.reset_episode()
                
                eps_reward = 0
                eps_length = 0
                
                for _ in range(self.config.max_eps_steps):
                    if self.config.render_mode:
                        self.env.render()
                    
                    # Use agent's select_action (handles recurrent automatically)
                    action, _, _ = self.agent.select_action(obs, deterministic=True)
                    obs, reward, done, _, _ = self.env.step(action)
                    
                    eps_reward += reward
                    eps_length += 1
                    
                    if done:
                        break
                
                metrics['eps_rewards'].append(eps_reward)
                metrics['eps_lengths'].append(eps_length)
                metrics['min_reward'] = min(metrics['min_reward'], eps_reward)
                metrics['max_reward'] = max(metrics['max_reward'], eps_reward)
                recent_rewards.append(eps_reward)
                
                self.log(f"Episode {ep+1}/{self.config.num_eval_eps} | Reward: {eps_reward:.2f} | Length: {eps_length}")
        
        # Summary statistics
        metrics['mean_reward'] = np.mean(metrics['eps_rewards'])
        metrics['std_reward'] = np.std(metrics['eps_rewards'])
        metrics['mean_eps_length'] = np.mean(metrics['eps_lengths'])
        
        self.log("\n" + "="*50)
        self.log("Evaluation Results:")
        self.log(f"Mean Reward: {metrics['mean_reward']:.2f} ± {metrics['std_reward']:.2f}")
        self.log(f"Min/Max Reward: {metrics['min_reward']:.2f} / {metrics['max_reward']:.2f}")
        self.log(f"Mean Episode Length: {metrics['mean_eps_length']:.1f}")
        self.log("="*50)
        
        return metrics