"""
Clean visualization of initial state distributions for thesis.

Shows what the agent "sees" as input:
1. Rimpoints: Distribution of displacement values
2. Tensions: Distribution of normalized tension values  
3. Fourier: Distribution per harmonic (box plot)
"""

import numpy as np
import matplotlib.pyplot as plt
import os
import sys

from wheel_env import WheelEnv


def collect_initial_states(n_samples=500, seed=42):
    """Collect initial states from environment resets."""
    np.random.seed(seed)
    
    env = WheelEnv(
        state_space_selection="fourier_and_spokes",
        len_theta=360,
        n_spokes=36,
        n_harmonics=20
    )
    
    env_rim = WheelEnv(
        state_space_selection="rimpoints",
        len_theta=360,
        n_spokes=36,
    )
    
    all_radial = []
    all_lateral = []
    all_tensions_normalized = []
    all_fourier_mag_rad = []
    all_fourier_mag_lat = []
    
    n_harmonics = env.n_harmonics
    
    print(f"Collecting {n_samples} initial states...")
    
    for i in range(n_samples):
        if (i + 1) % 100 == 0:
            print(f"  Progress: {i + 1}/{n_samples}")
        
        state_fourier, info = env.reset()
        
        n_fourier_features = 2 + 4 * n_harmonics
        fourier_part = state_fourier[:n_fourier_features]
        tensions_normalized = state_fourier[n_fourier_features:]
        
        # Parse fourier - get magnitudes only
        rad_mags = [fourier_part[0]]  # DC
        lat_mags = [fourier_part[1]]  # DC
        
        for k in range(n_harmonics):
            idx = 2 + k * 4
            rad_mags.append(fourier_part[idx])
            lat_mags.append(fourier_part[idx + 2])
        
        all_fourier_mag_rad.append(rad_mags)
        all_fourier_mag_lat.append(lat_mags)
        all_tensions_normalized.append(tensions_normalized)
        
        # Get rimpoints
        env_rim.spoke_turns = env.spoke_turns.copy()
        env_rim.tensionchanges = env.tensionchanges.copy()
        wheel_disp, _ = env_rim.wheel_calc(env_rim.tensionchanges, return_fourier=False)
        rimpoints = wheel_disp.reshape(-1, 2)
        
        all_radial.append(rimpoints[:, 0])
        all_lateral.append(rimpoints[:, 1])
    
    print("Done.")
    
    return {
        'radial': np.array(all_radial),
        'lateral': np.array(all_lateral),
        'tensions_normalized': np.array(all_tensions_normalized),
        'fourier_mag_rad': np.array(all_fourier_mag_rad),
        'fourier_mag_lat': np.array(all_fourier_mag_lat),
        'n_harmonics': n_harmonics,
    }


def plot_rimpoints_distribution(data, save_path='figures/dist_rimpoints.pdf'):
    """Single histogram for rimpoint displacements (radial + lateral combined or separate)."""
    
    radial = data['radial'].flatten()
    lateral = data['lateral'].flatten()
    
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    
    # Radial
    ax = axes[0]
    mean_r, std_r = np.mean(radial), np.std(radial)
    ax.hist(radial, bins=60, color='steelblue', alpha=0.7, edgecolor='black', linewidth=0.3)
    ax.axvline(mean_r, color='red', linewidth=2, linestyle='-')
    ax.axvline(mean_r - std_r, color='red', linewidth=1.5, linestyle='--')
    ax.axvline(mean_r + std_r, color='red', linewidth=1.5, linestyle='--')
    ax.set_xlabel('Radial Displacement [mm]')
    ax.set_ylabel('Frequency')
    ax.set_title('Radial Displacement Distribution')
    ax.text(0.97, 0.97, f'$\\mu = {mean_r:.4f}$\n$\\sigma = {std_r:.4f}$',
            transform=ax.transAxes, fontsize=10, verticalalignment='top', 
            horizontalalignment='right', bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    # Lateral
    ax = axes[1]
    mean_l, std_l = np.mean(lateral), np.std(lateral)
    ax.hist(lateral, bins=60, color='forestgreen', alpha=0.7, edgecolor='black', linewidth=0.3)
    ax.axvline(mean_l, color='red', linewidth=2, linestyle='-')
    ax.axvline(mean_l - std_l, color='red', linewidth=1.5, linestyle='--')
    ax.axvline(mean_l + std_l, color='red', linewidth=1.5, linestyle='--')
    ax.set_xlabel('Lateral Displacement [mm]')
    ax.set_ylabel('Frequency')
    ax.set_title('Lateral Displacement Distribution')
    ax.text(0.97, 0.97, f'$\\mu = {mean_l:.4f}$\n$\\sigma = {std_l:.4f}$',
            transform=ax.transAxes, fontsize=10, verticalalignment='top',
            horizontalalignment='right', bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    plt.close()


def plot_tensions_distribution(data, save_path='figures/dist_tensions.pdf'):
    """Single histogram for normalized spoke tensions."""
    
    tensions = data['tensions_normalized'].flatten()
    
    fig, ax = plt.subplots(figsize=(6, 4))
    
    mean_t, std_t = np.mean(tensions), np.std(tensions)
    
    ax.hist(tensions, bins=50, color='firebrick', alpha=0.7, edgecolor='black', linewidth=0.3)
    ax.axvline(mean_t, color='black', linewidth=2, linestyle='-')
    ax.axvline(mean_t - std_t, color='black', linewidth=1.5, linestyle='--')
    ax.axvline(mean_t + std_t, color='black', linewidth=1.5, linestyle='--')
    ax.axvline(1.0, color='orange', linewidth=2, linestyle=':', label='Initial tension (T/T₀ = 1)')
    
    ax.set_xlabel('Normalized Tension (T / T₀)')
    ax.set_ylabel('Frequency')
    ax.set_title('Distribution of Normalized Spoke Tensions')
    ax.legend(loc='upper right')
    
    ax.text(0.03, 0.97, f'$\\mu = {mean_t:.4f}$\n$\\sigma = {std_t:.4f}$',
            transform=ax.transAxes, fontsize=10, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    plt.close()


def plot_fourier_distribution(data, save_path='figures/dist_fourier.pdf'):
    """Box plot showing distribution of magnitudes per harmonic."""
    
    fourier_rad = data['fourier_mag_rad']  # (n_samples, n_harmonics+1)
    fourier_lat = data['fourier_mag_lat']
    n_harmonics = data['n_harmonics']
    
    fig, axes = plt.subplots(2, 1, figsize=(12, 6), sharex=True)
    
    # Radial
    ax = axes[0]
    bp = ax.boxplot([fourier_rad[:, i] for i in range(n_harmonics + 1)],
                    positions=range(n_harmonics + 1),
                    widths=0.6,
                    patch_artist=True,
                    showfliers=False)  # hide outliers for cleaner plot
    
    for patch in bp['boxes']:
        patch.set_facecolor('darkorange')
        patch.set_alpha(0.7)
    
    ax.set_ylabel('Magnitude')
    ax.set_title('Fourier Magnitude Distribution - Radial')
    ax.set_yscale('log')
    ax.grid(True, alpha=0.3, axis='y')
    
    # Lateral  
    ax = axes[1]
    bp = ax.boxplot([fourier_lat[:, i] for i in range(n_harmonics + 1)],
                    positions=range(n_harmonics + 1),
                    widths=0.6,
                    patch_artist=True,
                    showfliers=False)
    
    for patch in bp['boxes']:
        patch.set_facecolor('purple')
        patch.set_alpha(0.7)
    
    ax.set_ylabel('Magnitude')
    ax.set_xlabel('Harmonic Number (0 = DC)')
    ax.set_title('Fourier Magnitude Distribution - Lateral')
    ax.set_yscale('log')
    ax.grid(True, alpha=0.3, axis='y')
    ax.set_xticks(range(0, n_harmonics + 1, 2))
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    plt.close()


def plot_all_combined(data, save_path='figures/initial_state_distributions.pdf'):
    """
    Combined figure with all three distributions for thesis.
    2x2 layout: rimpoints (rad+lat), tensions, fourier
    """
    
    fig = plt.figure(figsize=(12, 10))
    
    # Create grid: 2 rows, 2 columns
    # Top row: radial, lateral
    # Bottom row: tensions, fourier (spanning or side by side)
    
    ax1 = fig.add_subplot(2, 2, 1)
    ax2 = fig.add_subplot(2, 2, 2)
    ax3 = fig.add_subplot(2, 2, 3)
    ax4 = fig.add_subplot(2, 2, 4)
    
    # --- Radial displacement ---
    radial = data['radial'].flatten()
    mean_r, std_r = np.mean(radial), np.std(radial)
    ax1.hist(radial, bins=60, color='steelblue', alpha=0.7, edgecolor='black', linewidth=0.3)
    ax1.axvline(mean_r, color='red', linewidth=2)
    ax1.axvline(mean_r - std_r, color='red', linewidth=1.5, linestyle='--')
    ax1.axvline(mean_r + std_r, color='red', linewidth=1.5, linestyle='--')
    ax1.set_xlabel('Radial Displacement [mm]')
    ax1.set_ylabel('Frequency')
    ax1.set_title('(a) Radial Displacement')
    ax1.text(0.97, 0.97, f'$\\mu={mean_r:.4f}$\n$\\sigma={std_r:.4f}$',
             transform=ax1.transAxes, fontsize=9, va='top', ha='right',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    # --- Lateral displacement ---
    lateral = data['lateral'].flatten()
    mean_l, std_l = np.mean(lateral), np.std(lateral)
    ax2.hist(lateral, bins=60, color='forestgreen', alpha=0.7, edgecolor='black', linewidth=0.3)
    ax2.axvline(mean_l, color='red', linewidth=2)
    ax2.axvline(mean_l - std_l, color='red', linewidth=1.5, linestyle='--')
    ax2.axvline(mean_l + std_l, color='red', linewidth=1.5, linestyle='--')
    ax2.set_xlabel('Lateral Displacement [mm]')
    ax2.set_ylabel('Frequency')
    ax2.set_title('(b) Lateral Displacement')
    ax2.text(0.97, 0.97, f'$\\mu={mean_l:.4f}$\n$\\sigma={std_l:.4f}$',
             transform=ax2.transAxes, fontsize=9, va='top', ha='right',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    # --- Normalized tensions ---
    tensions = data['tensions_normalized'].flatten()
    mean_t, std_t = np.mean(tensions), np.std(tensions)
    ax3.hist(tensions, bins=50, color='firebrick', alpha=0.7, edgecolor='black', linewidth=0.3)
    ax3.axvline(mean_t, color='black', linewidth=2)
    ax3.axvline(mean_t - std_t, color='black', linewidth=1.5, linestyle='--')
    ax3.axvline(mean_t + std_t, color='black', linewidth=1.5, linestyle='--')
    ax3.axvline(1.0, color='orange', linewidth=2, linestyle=':', label='T₀')
    ax3.set_xlabel('Normalized Tension (T / T₀)')
    ax3.set_ylabel('Frequency')
    ax3.set_title('(c) Spoke Tensions (Normalized)')
    ax3.legend(loc='upper right', fontsize=8)
    ax3.text(0.03, 0.97, f'$\\mu={mean_t:.4f}$\n$\\sigma={std_t:.4f}$',
             transform=ax3.transAxes, fontsize=9, va='top',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    # --- Fourier magnitudes (lateral only, cleaner) ---
    fourier_lat = data['fourier_mag_lat']
    n_harmonics = data['n_harmonics']
    
    bp = ax4.boxplot([fourier_lat[:, i] for i in range(n_harmonics + 1)],
                     positions=range(n_harmonics + 1),
                     widths=0.6, patch_artist=True, showfliers=False)
    for patch in bp['boxes']:
        patch.set_facecolor('purple')
        patch.set_alpha(0.7)
    
    ax4.set_xlabel('Harmonic Number')
    ax4.set_ylabel('Magnitude')
    ax4.set_title('(d) Fourier Magnitudes (Lateral)')
    ax4.set_yscale('log')
    ax4.grid(True, alpha=0.3, axis='y')
    ax4.set_xticks(range(0, n_harmonics + 1, 5))
    
    plt.suptitle('Distribution of Initial State Components', fontsize=14, fontweight='bold', y=1.02)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Saved: {save_path}")
    plt.close()


if __name__ == "__main__":
    os.makedirs('figures', exist_ok=True)
    
    data = collect_initial_states(n_samples=500, seed=42)
    
    # Print summary
    print("\n" + "="*50)
    print("SUMMARY")
    print("="*50)
    print(f"Radial:  μ={np.mean(data['radial']):.4f}, σ={np.std(data['radial']):.4f}")
    print(f"Lateral: μ={np.mean(data['lateral']):.4f}, σ={np.std(data['lateral']):.4f}")
    print(f"Tensions (norm): μ={np.mean(data['tensions_normalized']):.4f}, σ={np.std(data['tensions_normalized']):.4f}")
    print("="*50)
    
    # Generate individual plots
    plot_rimpoints_distribution(data)
    plot_tensions_distribution(data)
    plot_fourier_distribution(data)
    
    # Generate combined thesis figure
    plot_all_combined(data)
    
    print("\nDone! Check 'figures/' folder.")