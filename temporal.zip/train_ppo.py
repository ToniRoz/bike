import os
import random
import numpy as np
import torch
import hydra
from omegaconf import DictConfig, OmegaConf
from hydra.utils import instantiate

from Environment.wheel_env import WheelEnv
from trainers import PPOTrainer

# Import vectorized components
from wheel_env_vectorized import SubprocVecEnv, DummyVecEnv
from trainers import VectorizedPPOTrainer


def setup_logging(output_dir: str, use_tensorboard: bool = True):
    """Setup TensorBoard logging inside Hydra run dir"""
    if use_tensorboard:
        try:
            from torch.utils.tensorboard import SummaryWriter
            log_dir = os.path.join(output_dir, "tensorboard")
            os.makedirs(log_dir, exist_ok=True)
            writer = SummaryWriter(log_dir=log_dir)
            print(f"Logging to: {log_dir}")
            print(f"TensorBoard command: tensorboard --logdir {output_dir}")
            return writer
        except ImportError:
            print("Warning: tensorboard not available, using DummyWriter")
            return None
    return None


def train(cfg: DictConfig, output_dir: str = None):
    """Train PPO agent using Hydra with vectorized environments"""
    print("\n" + "=" * 50)
    print("Training PPO (Vectorized)")
    print("=" * 50)

    # Print current configuration
    print(OmegaConf.to_yaml(cfg))

    random.seed(cfg.random_seed)
    np.random.seed(cfg.random_seed)
    torch.manual_seed(cfg.random_seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(cfg.random_seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    if cfg.device == "cuda" and torch.cuda.is_available():
        device = torch.device("cuda")
        torch.cuda.empty_cache()
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        device = torch.device("mps")
    else:
        device = torch.device("cpu")

    cfg.device = str(device)
    print(f"Using device: {device}")


    if output_dir is None:
        try:
            output_dir = hydra.core.hydra_config.HydraConfig.get().runtime.output_dir
        except:
            output_dir = "outputs/default_run"
            os.makedirs(output_dir, exist_ok=True)
    
    writer = setup_logging(str(output_dir))


    n_envs = getattr(cfg, 'n_envs', 8)
    use_subproc = getattr(cfg, 'use_subproc', True)
    
    print(f"\nCreating {n_envs} parallel environments...")
    print(f"Using {'SubprocVecEnv' if use_subproc else 'DummyVecEnv'}")
    
    # Extract environment kwargs from config
    env_kwargs = OmegaConf.to_container(cfg.env, resolve=True)
    env_kwargs.pop('_target_', None)
    
    print(f"Environment kwargs: {env_kwargs}")
    

    def make_env(seed):
        def _init():
            env = WheelEnv(**env_kwargs)
            return env
        return _init
    
    # Create vectorized environment
    env_fns = [make_env(cfg.random_seed + i) for i in range(n_envs)]
    
    if use_subproc:
        vec_env = SubprocVecEnv(env_fns, start_method='spawn')
    else:
        vec_env = DummyVecEnv(env_fns)
    
    print(f"Vectorized environment created:")
    print(f"  - Observation space: {vec_env.observation_space}")
    print(f"  - Action space: {vec_env.action_space}")
    print(f"  - Num envs: {n_envs}")


    trainer = VectorizedPPOTrainer(
        config=cfg,
        vec_env=vec_env,
        writer=writer,
        output_dir=output_dir
    )


    mode = getattr(cfg, "mode", "train")
    if mode == "train":
        trainer.train()
    else:
        print("Note: Evaluation uses single environment")
        single_env = WheelEnv(**env_kwargs)
        single_trainer = PPOTrainer(cfg, single_env, writer, output_dir=output_dir)
        single_trainer.evaluate()
        single_env.close()

    if writer:
        writer.close()
    vec_env.close()


if __name__ == "__main__":
    @hydra.main(config_path="configs", config_name="ppo_default", version_base=None)
    def main(cfg: DictConfig):
        train(cfg)
    
    main()